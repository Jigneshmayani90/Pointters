//
//  AFClass.m
//  jCardz
//
//  Created by Arvind Mehta on 02/09/15.
//  Copyright (c) 2015 Arvind Mehta. All rights reserved.
//

#import "AFClass.h"

@implementation AFClass

+ (NSURLSessionDataTask *)postRequestWithURL:(NSString *)URL andParam:(NSDictionary *)param andHeader:(NSArray *)header response:(void (^)(NSDictionary *posts, NSError *error))block
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];

    NSMutableDictionary *postParamas = [[NSMutableDictionary alloc] init];
    
    // Remove White chareter space
    for (NSString *strKey  in [param allKeys])
    {
        if ([[param valueForKey:strKey] isKindOfClass:[NSString class]])
        {
            NSString *trimmed = [[param valueForKey:strKey] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            
            [postParamas setObject:trimmed forKey:strKey];
        }
        else
        {
            [postParamas setObject:[param valueForKey:strKey] forKey:strKey];
        }
    }

    
//    for (NSString *strKey in header)
//    {
//        if ([USERDEFAULT valueForKey:strKey])
//        {
//            NSLog(@"%@  %@",strKey,[USERDEFAULT valueForKey:strKey]);
//            
//            [manager.requestSerializer setValue:[USERDEFAULT valueForKey:strKey] forHTTPHeaderField:strKey];
//        }
//    }
    
    [SVProgressHUD showWithStatus:@"Loading..."];
    
    
    return [manager POST:URL parameters:postParamas progress:nil success:^(NSURLSessionDataTask *task, id responseObject)
            {
                [SVProgressHUD dismiss];
                
                if (block)
                {
                    block(responseObject, nil);
                }
                
            } failure:^(NSURLSessionDataTask *task, NSError *error)
            {
                [SVProgressHUD dismiss];
                NSLog(@"Error = %@",error);
                
                if (block)
                {
                    block(nil, error);
                }
                
            }];
}

+ (NSURLSessionDataTask *)getRequestWithURL:(NSString *)URL andParam:(NSDictionary *)param andHeader:(NSArray *)header response:(void (^)(NSDictionary *posts, NSError *error))block
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];

    [SVProgressHUD showWithStatus:@"Loading..."];

//    for (NSString *strKey in header)
//    {
//        if ([USERDEFAULT valueForKey:strKey])
//        {
//            [manager.requestSerializer setValue:[USERDEFAULT valueForKey:strKey] forHTTPHeaderField:strKey];
//        }
//    }
    
    return [manager GET:URL parameters:param progress:nil success:^(NSURLSessionTask *task, id responseObject)
            {
                [SVProgressHUD dismiss];
                if (block)
                {
                    block(responseObject, nil);
                }
            } failure:^(NSURLSessionTask *operation, NSError *error)
            {
                [SVProgressHUD dismiss];
                if (block)
                {
                    block([NSDictionary dictionary], error);
                }
            }];
}


@end
