//
//  Utility.swift
//  Parle
//
//  Created by Jignesh on 16/02/16.
//  Copyright © 2016 Jignesh. All rights reserved.
//

import UIKit
import BRYXBanner

class Utility: NSObject
{
    class func validateWhiteSpace(str: NSString) -> Bool
    {
            let trimmed: String = str.trimmingCharacters(in: NSCharacterSet.whitespaces)
            
            if trimmed.characters.count > 0
            {
                return true
            }
        
        return false
    }
    
    class func validateEmailWithString(email: String) -> Bool
    {
        //Email validation
        let emailRegex: String = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest: NSPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailTest.evaluate(with: email)
    }
    
    class func DisplayAlertWithTitle (title:String ,Body:String)
    {
        let banner = Banner(title: title, subtitle: Body, image:nil , backgroundColor: UIColor(red:48.00/255.0, green:174.0/255.0, blue:51.5/255.0, alpha:1.000))
        banner.dismissesOnTap = true
        banner.show(duration: 3.0)
    }
    
    

//    class func imageResize(sourceImage: UIImage, scaledToThis newSize: CGSize) -> UIImage
//    {
//        let newRatio: CGFloat = (sourceImage.size.width / sourceImage.size.height)
//        let oldRatio: CGFloat = newSize.width / newSize.height
//        let newHeight: CGFloat
//        let newWidth: CGFloat
//        
//        if newRatio >= oldRatio
//        {
//            newHeight = newSize.height
//            newWidth = (newSize.height * sourceImage.size.width) / (sourceImage.size.height)
//        }
//        else
//        {
//            newWidth = newSize.width
//            newHeight = (newSize.width * sourceImage.size.height) / sourceImage.size.width
//        }
//        UIGraphicsBeginImageContex)
//        
//        sourceImage.draw(in: CGRectMake(0, 0, newWidth, newHeight))
//        
//        let newImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
//        UIGraphicsEndImageContext()
//        
//        return newImage
//    }
    
    class func getWidthOfstring(string:NSString,height: CGFloat, font: UIFont) -> CGFloat
   {
        let constraintRect = CGSize(width:9999,height:height)
        
        let boundingBox = string.boundingRect(with: constraintRect, options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSFontAttributeName: font], context: nil)
    
        return boundingBox.width
    }
    
    class func addCornerRadious(object: AnyObject, redious radious: CGFloat)
    {
        let view: UIView = (object as! UIView)
        view.layer.cornerRadius = radious
        view.layer.masksToBounds = true
        view.layer.borderColor = UIColor.black.cgColor
        view.layer.borderWidth = 1
    }
    
    class func DisplayAlert(Title: String, Message message: String, onController controller:UIViewController)
    {
        let banner = Banner(title: Title, subtitle: message, image:nil , backgroundColor: UIColor(red:48.00/255.0, green:174.0/255.0, blue:51.5/255.0, alpha:1.000))
        banner.dismissesOnTap = true
        banner.show(duration: 3.0)
        
//        let alert = UIAlertController(title:Title, message: message, preferredStyle: UIAlertControllerStyle.alert)
//        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
//        controller.present(alert, animated: true, completion: nil)
    }
    
//    class func getStringHeight(string: String, width: CGFloat, font usedFont: UIFont) -> CGFloat
//    {
//        let sizeOfString = string.boundingRect(
//            with: CGSizeMake(width, CGFloat.infinity),
//            options: NSStringDrawingOptions.usesLineFragmentOrigin,
//            attributes: [NSFontAttributeName: usedFont],
//            context: nil).size
//
//        return sizeOfString.height
//    }
    
    class func addCornerRadious(_ object: Any, redious radious: Int, withBordercolour colour: UIColor) -> Any
    {
        let view = (object as! UIView)
        view.layer.cornerRadius = CGFloat(radious)
        view.layer.masksToBounds = true
        view.layer.borderColor = colour.cgColor
        view.layer.borderWidth = 1
        return view
    }
    
    class func addLeftPadding(_ object: UITextField, padding radious: Int)
    {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: radious, height: Int(object.frame.size.height)))
        
        object.leftView = paddingView
        
        object.leftViewMode = .always
    }
    class func getDateFormTimestamp(timeStamp:String) -> NSDate
    {
        let unixTimeStamp: Double = CDouble(timeStamp)!
        let interval: TimeInterval = unixTimeStamp
        let date: NSDate = NSDate(timeIntervalSince1970: interval)
        
        return date
    }
}
