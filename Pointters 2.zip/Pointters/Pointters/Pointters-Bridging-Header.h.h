
//
//  Header.h
//  Pointters
//
//  Created by Jignesh on 08/10/16.
//  Copyright © 2016 SilverSky Technology. All rights reserved.
//

#ifndef Header_h
#define Header_h

#define RGB(r,g,b)[UIColor colorWithRed:(r/255.0) green:(g/255.0) blue:(b/255.0) alpha:1.0]

#import <CommonCrypto/CommonCrypto.h>
#import "AFClass.h"
#import <SVProgressHUD/SVProgressHUD.h>

#endif /* Header_h */
