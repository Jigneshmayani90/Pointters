//
//  AFClass.h
//  jCardz
//
//  Created by Arvind Mehta on 02/09/15.
//  Copyright (c) 2015 Arvind Mehta. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFHTTPSessionManager.h>
#import <SVProgressHUD/SVProgressHUD.h>


@interface AFClass : NSObject

+ (NSURLSessionDataTask *)postRequestWithURL:(NSString *)URL andParam:(NSDictionary *)param andHeader:(NSArray *)header response:(void (^)(NSDictionary *posts, NSError *error))block;

+ (NSURLSessionDataTask *)getRequestWithURL:(NSString *)URL andParam:(NSDictionary *)param andHeader:(NSArray *)header response:(void (^)(NSDictionary *posts, NSError *error))block;

@end
