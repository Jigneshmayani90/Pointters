//
//  LoginViewController.swift
//  Pointters
//
//  Created by Jignesh on 07/10/16.
//  Copyright © 2016 SilverSky Technology. All rights reserved.
//

import UIKit
import AFNetworking


class LoginViewController: UIViewController
{
    @IBOutlet var txtEmail:UITextField!
    @IBOutlet var txtPassWord:UITextField!
  
    override func viewDidLoad()
    {
        Utility.addLeftPadding(txtEmail, padding: 40)
        Utility.addLeftPadding(txtPassWord, padding: 40)

        Utility.addCornerRadious(object: txtEmail, redious: 25)
        Utility.addCornerRadious(object: txtPassWord, redious: 25)

        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func LoginButtonTapped(sender: UIButton)
    {
        if !Utility.validateWhiteSpace(str: txtEmail.text! as NSString)
        {
            Utility.DisplayAlert(Title: "Pointters", Message: "Please enter email address", onController: self)

            return;
        }
        else if !Utility.validateEmailWithString(email: (txtEmail.text! as NSString) as String)
        {
            Utility.DisplayAlert(Title: "Pointters", Message: "Please enter valid email address", onController: self)
            
            return;
        }
        else if !Utility.validateWhiteSpace(str: txtPassWord.text! as NSString)
        {
            Utility.DisplayAlert(Title: "Pointters", Message: "Please enter Password", onController: self)
                    
            return;
        }

        
        
        let manager = AFHTTPSessionManager()

        manager.requestSerializer = AFJSONRequestSerializer()
        
        manager.responseSerializer = AFHTTPResponseSerializer()

        let parameters = ["email":txtEmail.text! as String,"password": self.sha1(string: txtPassWord.text!) ] as NSDictionary
        
        AFClass.postRequest(withURL: "http://pointtersdev.us-east-1.elasticbeanstalk.com/api/authuser", andParam: parameters as [NSObject : AnyObject], andHeader:nil, response:
            { (posts, error)  -> Void in
              
                if posts!["success"] as! Bool
                {
                    Utility.DisplayAlert(Title: "Pointters", Message:"Login Sucess", onController: self)
                }
                else
                {
                    let data : String = posts!["message"] as! String
                    
                    Utility.DisplayAlert(Title: "Pointters", Message: data, onController: self)
                }
        })
    }
    
    
    
    func sha1(string:String) -> String
    {
        let data = string.data(using: String.Encoding.utf8)!
        var digest = [UInt8](repeating: 0, count:Int(CC_SHA1_DIGEST_LENGTH))
        data.withUnsafeBytes
            {
            _ = CC_SHA1($0, CC_LONG(data.count), &digest)
        }
        let hexBytes = digest.map { String(format: "%02hhx", $0) }
        return hexBytes.joined()
    }

}
